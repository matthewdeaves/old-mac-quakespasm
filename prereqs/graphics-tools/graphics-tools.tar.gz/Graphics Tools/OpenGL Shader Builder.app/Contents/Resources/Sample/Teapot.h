/* Functions */
void DrawTeapot(void);
