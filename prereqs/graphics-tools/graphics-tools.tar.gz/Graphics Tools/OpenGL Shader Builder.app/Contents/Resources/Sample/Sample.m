#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#include <stdio.h>
#include <stdlib.h>
#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#include <OpenGL/glu.h>
#include "Sample.h"

SampleScene * SampleSceneCreate(void)
{
   SampleScene *ss;

   ss = (SampleScene *) calloc(sizeof(SampleScene), 1);
   return ss;
}

void SampleSceneFree(SampleScene *ss)
{
   free(ss);
}

void SampleSceneSetupViewport(SampleScene *ss, GLint width, GLint height)
{
   GLdouble aspect;
   const GLdouble kFOVy = 0.57735;
   const GLdouble kZNear = 0.1;

   glViewport(0, 0, width, height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   aspect = width/height;
   aspect *= (kZNear * kFOVy);
   glFrustum(-aspect, aspect, -(kZNear * kFOVy), (kZNear * kFOVy), kZNear, 1000.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void SampleSceneSetupTextures(SampleScene *ss)
{
}

void SampleSceneSetupTextureCombiners(SampleScene *ss)
{
}

void SampleSceneGenerateMesh(SampleScene *ss)
{
   GLUquadric *quad;

   quad = gluNewQuadric();
   gluQuadricTexture(quad, GL_TRUE);
   gluQuadricNormals(quad, GLU_SMOOTH);
   gluSphere(quad, 0.50, 60, 60);
   gluDeleteQuadric(quad);
}

void SampleSceneSetupVertexShader(SampleScene *ss, unsigned char *string)
{
   glProgramStringARB(GL_VERTEX_PROGRAM_ARB, GL_VERTEX_PROGRAM_LANGUAGE_ARB, strlen(string), string);
   glEnable(GL_VERTEX_PROGRAM_ARB);
}

void SampleSceneSetup(SampleScene *ss, unsigned char *vertexprogramstring)
{
   SampleSceneSetupTextures(ss);
   SampleSceneSetupTextureCombiners(ss);
   SampleSceneSetupVertexShader(ss, vertexprogramstring);
}

void SampleSceneRenderFrame(SampleScene *ss)
{
   glClearColor(0.40, 0.40, 0.40, 1.00);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glEnable(GL_CULL_FACE);
   glEnable(GL_DEPTH_TEST);
   glPushMatrix();
   glTranslatef(0.0, 0.0, -2.0);
   glRotatef(0.00, 1.00, 0.00, 0.00);
   glRotatef(0.00, 0.00, 1.00, 0.00);
   glRotatef(0.00, 0.00, 0.00, 1.00);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glColor4f(0.76, 0.50, 0.43, 1.00);
   SampleSceneGenerateMesh(ss);
   glPopMatrix();
}

