#import <Foundation/Foundation.h>
/*#import <Cocoa/Cocoa.h>
  #import <AppKit/AppKit.h>*/
#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#include <GLUT/glut.h>
#include "Sample.h"

SampleScene *samplescene;

void ReshapeWindowFunc(int w, int h)
{
   SampleSceneSetupViewport(samplescene, w, h);
}

void MainRenderLoop(void)
{
   SampleSceneRenderFrame(samplescene);
   glFlush();
}

void KeyboardHandler(unsigned char key, int x, int y)
{
   switch (key) {
   case 27:
      SampleSceneFree(samplescene);
      exit(0);
      break;
   }
}

int main(int argc, char **argv)
{
   NSString *vertexprogramstring;
	NSString *fragmentprogramstring;
	NSAutoreleasePool *autoreleasepool;
	
	autoreleasepool = [[NSAutoreleasePool alloc] init];

   /* Initialise GLUT for visualisation */
   glutInit(&argc, argv);
   glutInitWindowSize(400, 400);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);
   glutCreateWindow(argv[0]);
   glutDisplayFunc(MainRenderLoop);
   glutIdleFunc(MainRenderLoop);
   glutReshapeFunc(ReshapeWindowFunc);
   glutKeyboardFunc(KeyboardHandler);

   [[NSFileManager defaultManager] changeCurrentDirectoryPath: 
				     [[NSBundle mainBundle] bundlePath]];
   
   /* Load the vertex program */
   vertexprogramstring = [NSString stringWithContentsOfFile: 
												 @"../../VertexProgram"];
   fragmentprogramstring = [NSString stringWithContentsOfFile:
													@"../../FragmentProgram"];

   /* Create an instance of the sample scene */
   samplescene = SampleSceneCreate();
   /* Setup the GL state */
   SampleSceneSetupViewport(samplescene, 400, 400);
   SampleSceneSetup(samplescene, (unsigned char *) [vertexprogramstring cString],
						  (unsigned char *) [fragmentprogramstring cString]);
  
   glutMainLoop();

   [autoreleasepool release];

   return 0;
}
