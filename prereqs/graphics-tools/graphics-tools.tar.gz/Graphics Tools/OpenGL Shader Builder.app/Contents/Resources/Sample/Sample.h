/* Structures */
typedef struct _SampleScene {
} SampleScene;

/* Function Prototypes */
SampleScene * SampleSceneCreate(void);
void SampleSceneFree(SampleScene *ss);
void SampleSceneSetupViewport(SampleScene *ss, GLint width, GLint height);
void SampleSceneSetupTextures(SampleScene *ss);
void SampleSceneSetupTextureCombiners(SampleScene *ss);
void SampleSceneGenerateMesh(SampleScene *ss);
void SampleSceneSetupVertexShader(SampleScene *ss, unsigned char *string);
void SampleSceneSetup(SampleScene *ss, unsigned char *vertexprogramstring);
void SampleSceneRenderFrame(SampleScene *ss);
